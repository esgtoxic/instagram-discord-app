package com.esg.bouncepocket;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class GameView extends View {
    private static final float VW = 480f;
    private static final float VH = 800f;
    private static final float PLAY_BOTTOM = 650f;
    private static final float BALL_R = 16f;
    private static final float GRAVITY = 1450f;
    private static final float BOUNCE_V = -560f;
    private static final float SPRING_V = -770f;
    private static final float MOVE_ACCEL = 820f;
    private static final float MAX_VX = 245f;

    private static final int MENU = 0;
    private static final int PLAYING = 1;
    private static final int LEVEL_COMPLETE = 2;
    private static final int GAME_OVER = 3;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SharedPreferences prefs;

    private final List<Platform> platforms = new ArrayList<>();
    private final List<Spike> spikes = new ArrayList<>();
    private final List<Ring> rings = new ArrayList<>();
    private final List<SpringPad> springs = new ArrayList<>();
    private final List<Checkpoint> checkpoints = new ArrayList<>();

    private float ballX, ballY, prevBallY, vx, vy;
    private float respawnX, respawnY;
    private float cameraX = 0f;
    private float worldWidth = 2200f;
    private float exitX, exitY;
    private int level = 1;
    private int lives = 3;
    private int ringsCollected = 0;
    private int totalRings = 0;
    private int state = MENU;
    private int unlockedLevel;
    private boolean paused = false;
    private boolean leftPressed = false;
    private boolean rightPressed = false;
    private int leftPointer = -1;
    private int rightPointer = -1;
    private long lastFrame = 0L;
    private boolean loopRunning = true;
    private long stateSince = 0L;

    private final Runnable frameRunnable = new Runnable() {
        @Override public void run() {
            if (!loopRunning) return;
            long now = SystemClock.elapsedRealtimeNanos();
            if (lastFrame == 0L) lastFrame = now;
            float dt = (now - lastFrame) / 1_000_000_000f;
            lastFrame = now;
            if (dt > 0.033f) dt = 0.033f;
            if (state == PLAYING && !paused) update(dt);
            invalidate();
            postOnAnimation(this);
        }
    };

    public GameView(Context context) {
        super(context);
        setFocusable(true);
        setKeepScreenOn(true);
        prefs = context.getSharedPreferences("bounce_pocket", Context.MODE_PRIVATE);
        unlockedLevel = Math.max(1, Math.min(3, prefs.getInt("unlocked", 1)));
        level = unlockedLevel;

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setColor(Color.rgb(24, 33, 26));
        post(frameRunnable);
    }

    public void pauseGameLoop() {
        loopRunning = false;
        removeCallbacks(frameRunnable);
        lastFrame = 0L;
    }

    public void resumeGameLoop() {
        if (loopRunning) return;
        loopRunning = true;
        lastFrame = 0L;
        post(frameRunnable);
    }

    private void startLevel(int which, boolean resetLives) {
        level = Math.max(1, Math.min(3, which));
        if (resetLives) lives = 3;
        state = PLAYING;
        paused = false;
        stateSince = SystemClock.elapsedRealtime();
        ringsCollected = 0;
        cameraX = 0f;
        loadLevel(level);
        respawnX = ballX;
        respawnY = ballY;
    }

    private void loadLevel(int n) {
        platforms.clear();
        spikes.clear();
        rings.clear();
        springs.clear();
        checkpoints.clear();

        if (n == 1) buildLevel1();
        else if (n == 2) buildLevel2();
        else buildLevel3();

        totalRings = rings.size();
        vx = 0f;
        vy = 0f;
    }

    private void buildLevel1() {
        worldWidth = 2200f;
        ballX = 90f; ballY = 510f;
        exitX = 2080f; exitY = 478f;

        p(0, 555, 320, 40);
        p(370, 530, 300, 65);
        p(720, 570, 240, 25);
        p(1010, 520, 260, 75);
        p(1325, 560, 250, 35);
        p(1630, 500, 300, 95);
        p(1980, 555, 220, 40);

        p(260, 430, 150, 24);
        p(575, 385, 150, 24);
        p(900, 405, 150, 24);
        p(1210, 350, 170, 24);
        p(1510, 380, 140, 24);
        p(1780, 330, 170, 24);

        ring(335, 395); ring(650, 350); ring(970, 370);
        ring(1295, 315); ring(1580, 345); ring(1860, 295);
        ring(1450, 520); ring(1740, 460);

        spike(815, 548, 90, 22);
        spike(1395, 538, 80, 22);
        spring(1110, 500, 70, 18);
        checkpoint(1180, 472);
    }

    private void buildLevel2() {
        worldWidth = 2580f;
        ballX = 80f; ballY = 505f;
        exitX = 2460f; exitY = 450f;

        p(0, 550, 270, 45);
        p(340, 575, 210, 20);
        p(620, 520, 250, 75);
        p(930, 560, 180, 35);
        p(1180, 510, 260, 85);
        p(1510, 565, 220, 30);
        p(1800, 515, 250, 80);
        p(2120, 570, 190, 25);
        p(2370, 525, 210, 70);

        p(220, 415, 135, 22);
        p(455, 350, 145, 22);
        p(760, 385, 155, 22);
        p(1040, 330, 145, 22);
        p(1340, 365, 150, 22);
        p(1600, 300, 160, 22);
        p(1910, 360, 150, 22);
        p(2190, 310, 160, 22);

        ring(285, 380); ring(525, 315); ring(835, 350); ring(1110, 295);
        ring(1415, 330); ring(1680, 265); ring(1985, 325); ring(2270, 275);
        ring(700, 480); ring(1280, 470); ring(1880, 475);

        spike(390, 553, 105, 22);
        spike(990, 538, 70, 22);
        spike(1570, 543, 95, 22);
        spike(2160, 548, 95, 22);
        spring(655, 500, 75, 18);
        spring(1840, 495, 75, 18);
        checkpoint(1320, 462);
    }

    private void buildLevel3() {
        worldWidth = 2980f;
        ballX = 80f; ballY = 500f;
        exitX = 2865f; exitY = 435f;

        p(0, 545, 240, 50);
        p(305, 580, 180, 15);
        p(550, 525, 210, 70);
        p(830, 570, 190, 25);
        p(1085, 505, 200, 90);
        p(1355, 555, 200, 40);
        p(1620, 500, 210, 95);
        p(1900, 570, 165, 25);
        p(2130, 515, 220, 80);
        p(2415, 565, 185, 30);
        p(2670, 510, 310, 85);

        p(185, 400, 125, 22);
        p(420, 330, 145, 22);
        p(690, 390, 135, 22);
        p(940, 310, 150, 22);
        p(1190, 365, 145, 22);
        p(1460, 285, 155, 22);
        p(1740, 350, 145, 22);
        p(1990, 275, 150, 22);
        p(2260, 355, 145, 22);
        p(2530, 300, 150, 22);
        p(2770, 360, 155, 22);

        ring(245, 365); ring(495, 295); ring(755, 355); ring(1015, 275);
        ring(1260, 330); ring(1535, 250); ring(1810, 315); ring(2065, 240);
        ring(2330, 320); ring(2605, 265); ring(2845, 325);
        ring(640, 485); ring(1150, 465); ring(1700, 460); ring(2200, 475); ring(2740, 470);

        spike(335, 558, 100, 22);
        spike(875, 548, 100, 22);
        spike(1388, 533, 120, 22);
        spike(1930, 548, 100, 22);
        spike(2450, 543, 110, 22);
        spring(575, 505, 75, 18);
        spring(1645, 480, 75, 18);
        spring(2695, 490, 75, 18);
        checkpoint(1495, 260);
        checkpoint(2290, 330);
    }

    private void p(float x, float y, float w, float h) {
        platforms.add(new Platform(x, y, w, h));
    }

    private void spike(float x, float y, float w, float h) {
        spikes.add(new Spike(x, y, w, h));
    }

    private void ring(float x, float y) {
        rings.add(new Ring(x, y));
    }

    private void spring(float x, float y, float w, float h) {
        springs.add(new SpringPad(x, y, w, h));
    }

    private void checkpoint(float x, float y) {
        checkpoints.add(new Checkpoint(x, y));
    }

    private void update(float dt) {
        if (leftPressed && !rightPressed) vx -= MOVE_ACCEL * dt;
        else if (rightPressed && !leftPressed) vx += MOVE_ACCEL * dt;
        else vx *= (float)Math.pow(0.15, dt);

        if (vx > MAX_VX) vx = MAX_VX;
        if (vx < -MAX_VX) vx = -MAX_VX;

        prevBallY = ballY;
        vy += GRAVITY * dt;
        ballX += vx * dt;
        ballY += vy * dt;

        if (ballX < BALL_R) {
            ballX = BALL_R;
            vx = Math.abs(vx) * 0.45f;
        }
        if (ballX > worldWidth - BALL_R) {
            ballX = worldWidth - BALL_R;
            vx = -Math.abs(vx) * 0.45f;
        }

        boolean landed = false;
        float previousBottom = prevBallY + BALL_R;
        float currentBottom = ballY + BALL_R;

        if (vy >= 0f) {
            for (SpringPad s : springs) {
                if (ballX + BALL_R > s.x && ballX - BALL_R < s.x + s.w
                        && previousBottom <= s.y + 6f && currentBottom >= s.y) {
                    ballY = s.y - BALL_R;
                    vy = SPRING_V;
                    landed = true;
                    break;
                }
            }

            if (!landed) {
                for (Platform p : platforms) {
                    if (ballX + BALL_R > p.x && ballX - BALL_R < p.x + p.w
                            && previousBottom <= p.y + 5f && currentBottom >= p.y) {
                        ballY = p.y - BALL_R;
                        vy = BOUNCE_V;
                        landed = true;
                        break;
                    }
                }
            }
        }

        RectF ballBox = new RectF(ballX - BALL_R + 3f, ballY - BALL_R + 3f,
                ballX + BALL_R - 3f, ballY + BALL_R - 3f);
        for (Spike s : spikes) {
            RectF sr = new RectF(s.x, s.y, s.x + s.w, s.y + s.h);
            if (RectF.intersects(ballBox, sr)) {
                loseLife();
                return;
            }
        }

        for (Ring r : rings) {
            if (!r.collected) {
                float dx = ballX - r.x;
                float dy = ballY - r.y;
                if (dx * dx + dy * dy < 30f * 30f) {
                    r.collected = true;
                    ringsCollected++;
                    performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
                }
            }
        }

        for (Checkpoint cp : checkpoints) {
            if (!cp.activated && Math.abs(ballX - cp.x) < 28f && Math.abs(ballY - cp.y) < 55f) {
                cp.activated = true;
                respawnX = cp.x;
                respawnY = cp.y - 25f;
                performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
            }
        }

        if (ringsCollected == totalRings) {
            RectF exit = new RectF(exitX, exitY, exitX + 52f, exitY + 78f);
            if (RectF.intersects(ballBox, exit)) {
                completeLevel();
                return;
            }
        }

        if (ballY - BALL_R > PLAY_BOTTOM + 70f) {
            loseLife();
            return;
        }

        float targetCamera = ballX - VW * 0.43f;
        float maxCamera = Math.max(0f, worldWidth - VW);
        if (targetCamera < 0f) targetCamera = 0f;
        if (targetCamera > maxCamera) targetCamera = maxCamera;
        cameraX += (targetCamera - cameraX) * Math.min(1f, dt * 7f);
    }

    private void loseLife() {
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
        lives--;
        leftPressed = rightPressed = false;
        leftPointer = rightPointer = -1;
        if (lives <= 0) {
            state = GAME_OVER;
            stateSince = SystemClock.elapsedRealtime();
            return;
        }
        ballX = respawnX;
        ballY = respawnY;
        vx = 0f;
        vy = -260f;
        cameraX = Math.max(0f, Math.min(worldWidth - VW, ballX - VW * 0.35f));
    }

    private void completeLevel() {
        state = LEVEL_COMPLETE;
        stateSince = SystemClock.elapsedRealtime();
        if (level < 3 && unlockedLevel < level + 1) {
            unlockedLevel = level + 1;
            prefs.edit().putInt("unlocked", unlockedLevel).apply();
        }
        performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float sx = getWidth() / VW;
        float sy = getHeight() / VH;
        canvas.save();
        canvas.scale(sx, sy);

        drawBackground(canvas);
        if (state == MENU) drawMenu(canvas);
        else {
            drawWorld(canvas);
            drawHud(canvas);
            drawControls(canvas);
            if (paused) drawPauseOverlay(canvas);
            if (state == LEVEL_COMPLETE) drawLevelComplete(canvas);
            if (state == GAME_OVER) drawGameOver(canvas);
        }

        canvas.restore();
    }

    private void drawBackground(Canvas c) {
        c.drawColor(Color.rgb(218, 231, 196));
        paint.setColor(Color.rgb(201, 218, 177));
        paint.setStyle(Paint.Style.FILL);
        for (int i = -1; i < 8; i++) {
            float x = i * 90f - (cameraX * 0.08f % 90f);
            Path hill = new Path();
            hill.moveTo(x, 620f);
            hill.quadTo(x + 45f, 520f, x + 90f, 620f);
            hill.close();
            c.drawPath(hill, paint);
        }
        paint.setColor(Color.rgb(188, 207, 163));
        for (int i = -1; i < 7; i++) {
            float x = i * 115f - (cameraX * 0.14f % 115f);
            c.drawCircle(x + 55f, 170f + (i % 2) * 35f, 20f, paint);
            c.drawCircle(x + 80f, 165f + (i % 2) * 35f, 15f, paint);
        }
        paint.setColor(Color.rgb(24, 33, 26));
        paint.setStrokeWidth(2f);
        c.drawLine(0f, PLAY_BOTTOM, VW, PLAY_BOTTOM, paint);
    }

    private void drawMenu(Canvas c) {
        paint.setColor(Color.rgb(24, 33, 26));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD));
        paint.setTextSize(52f);
        c.drawText("BOUNCE", VW / 2f, 190f, paint);
        paint.setTextSize(22f);
        c.drawText("POCKET", VW / 2f, 222f, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(215, 58, 58));
        c.drawCircle(VW / 2f, 305f, 43f, paint);
        stroke.setColor(Color.rgb(24, 33, 26));
        stroke.setStrokeWidth(4f);
        c.drawCircle(VW / 2f, 305f, 43f, stroke);
        paint.setColor(Color.rgb(255, 238, 225));
        c.drawCircle(VW / 2f - 13f, 292f, 8f, paint);

        paint.setColor(Color.rgb(24, 33, 26));
        paint.setTextSize(17f);
        c.drawText("AUTO-BOUNCE • LEFT / RIGHT", VW / 2f, 385f, paint);
        c.drawText("COLLECT EVERY RING TO OPEN THE EXIT", VW / 2f, 412f, paint);

        RectF play = new RectF(95f, 470f, 385f, 545f);
        paint.setColor(Color.rgb(24, 33, 26));
        c.drawRoundRect(play, 18f, 18f, paint);
        paint.setColor(Color.rgb(218, 231, 196));
        paint.setTextSize(24f);
        c.drawText("PLAY LEVEL " + level, VW / 2f, 518f, paint);

        paint.setTextSize(15f);
        paint.setColor(Color.rgb(50, 65, 52));
        c.drawText("Unlocked: " + unlockedLevel + "/3", VW / 2f, 580f, paint);
        if (unlockedLevel > 1) {
            c.drawText("Tap ◀ or ▶ beside the level number to choose", VW / 2f, 610f, paint);
            paint.setTextSize(36f);
            c.drawText("◀", 60f, 512f, paint);
            c.drawText("▶", 420f, 512f, paint);
        }

        paint.setTextSize(13f);
        paint.setColor(Color.rgb(70, 84, 70));
        c.drawText("Original retro-inspired game • no internet needed", VW / 2f, 705f, paint);
    }

    private void drawWorld(Canvas c) {
        c.save();
        c.clipRect(0f, 0f, VW, PLAY_BOTTOM);
        c.translate(-cameraX, 0f);

        for (Platform p : platforms) drawPlatform(c, p);
        for (SpringPad s : springs) drawSpring(c, s);
        for (Spike s : spikes) drawSpike(c, s);
        for (Ring r : rings) if (!r.collected) drawRing(c, r);
        for (Checkpoint cp : checkpoints) drawCheckpoint(c, cp);
        drawExit(c);
        drawBall(c);

        c.restore();
    }

    private void drawPlatform(Canvas c, Platform p) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(64, 86, 67));
        RectF r = new RectF(p.x, p.y, p.x + p.w, p.y + p.h);
        c.drawRoundRect(r, 7f, 7f, paint);
        paint.setColor(Color.rgb(126, 151, 116));
        c.drawRect(p.x + 4f, p.y + 4f, p.x + p.w - 4f, p.y + 10f, paint);
        stroke.setStrokeWidth(2.5f);
        stroke.setColor(Color.rgb(24, 33, 26));
        c.drawRoundRect(r, 7f, 7f, stroke);
    }

    private void drawSpring(Canvas c, SpringPad s) {
        paint.setColor(Color.rgb(66, 137, 133));
        RectF r = new RectF(s.x, s.y, s.x + s.w, s.y + s.h);
        c.drawRoundRect(r, 5f, 5f, paint);
        stroke.setColor(Color.rgb(24, 33, 26));
        stroke.setStrokeWidth(2.5f);
        c.drawRoundRect(r, 5f, 5f, stroke);
        paint.setColor(Color.rgb(24, 33, 26));
        paint.setStrokeWidth(3f);
        float step = s.w / 5f;
        for (int i = 1; i < 5; i++) c.drawLine(s.x + step * i, s.y + 3f, s.x + step * i, s.y + s.h - 3f, paint);
    }

    private void drawSpike(Canvas c, Spike s) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(50, 58, 51));
        int count = Math.max(2, (int)(s.w / 22f));
        float tw = s.w / count;
        for (int i = 0; i < count; i++) {
            Path path = new Path();
            path.moveTo(s.x + i * tw, s.y + s.h);
            path.lineTo(s.x + i * tw + tw / 2f, s.y);
            path.lineTo(s.x + (i + 1) * tw, s.y + s.h);
            path.close();
            c.drawPath(path, paint);
        }
    }

    private void drawRing(Canvas c, Ring r) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(6f);
        paint.setColor(Color.rgb(208, 156, 39));
        c.drawCircle(r.x, r.y, 13f, paint);
        paint.setStrokeWidth(2f);
        paint.setColor(Color.rgb(24, 33, 26));
        c.drawCircle(r.x, r.y, 16f, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawCheckpoint(Canvas c, Checkpoint cp) {
        paint.setColor(Color.rgb(24, 33, 26));
        c.drawRect(cp.x - 2f, cp.y - 52f, cp.x + 2f, cp.y + 18f, paint);
        Path flag = new Path();
        flag.moveTo(cp.x + 2f, cp.y - 50f);
        flag.lineTo(cp.x + 34f, cp.y - 38f);
        flag.lineTo(cp.x + 2f, cp.y - 25f);
        flag.close();
        paint.setColor(cp.activated ? Color.rgb(55, 145, 88) : Color.rgb(165, 178, 150));
        c.drawPath(flag, paint);
        stroke.setStrokeWidth(2f);
        stroke.setColor(Color.rgb(24, 33, 26));
        c.drawPath(flag, stroke);
    }

    private void drawExit(Canvas c) {
        boolean open = ringsCollected == totalRings;
        RectF body = new RectF(exitX, exitY, exitX + 52f, exitY + 78f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(open ? Color.rgb(69, 151, 90) : Color.rgb(124, 126, 113));
        c.drawRoundRect(body, 7f, 7f, paint);
        stroke.setColor(Color.rgb(24, 33, 26));
        stroke.setStrokeWidth(3f);
        c.drawRoundRect(body, 7f, 7f, stroke);
        paint.setColor(Color.rgb(218, 231, 196));
        c.drawCircle(exitX + 39f, exitY + 41f, 4f, paint);
        if (!open) {
            paint.setColor(Color.rgb(24, 33, 26));
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            paint.setTextSize(12f);
            c.drawText("LOCK", exitX + 26f, exitY - 8f, paint);
        }
    }

    private void drawBall(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(215, 58, 58));
        c.drawCircle(ballX, ballY, BALL_R, paint);
        stroke.setStrokeWidth(3f);
        stroke.setColor(Color.rgb(24, 33, 26));
        c.drawCircle(ballX, ballY, BALL_R, stroke);
        paint.setColor(Color.rgb(255, 232, 220));
        c.drawCircle(ballX - 5f, ballY - 6f, 4f, paint);
    }

    private void drawHud(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(220, 218, 231, 196));
        c.drawRoundRect(new RectF(12f, 12f, 325f, 58f), 12f, 12f, paint);
        stroke.setColor(Color.rgb(24, 33, 26));
        stroke.setStrokeWidth(2f);
        c.drawRoundRect(new RectF(12f, 12f, 325f, 58f), 12f, 12f, stroke);
        paint.setColor(Color.rgb(24, 33, 26));
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        paint.setTextSize(17f);
        c.drawText("LEVEL " + level, 26f, 42f, paint);
        c.drawText("♥ " + lives, 118f, 42f, paint);
        c.drawText("RINGS " + ringsCollected + "/" + totalRings, 190f, 42f, paint);

        paint.setColor(Color.argb(220, 218, 231, 196));
        c.drawCircle(443f, 35f, 23f, paint);
        stroke.setColor(Color.rgb(24, 33, 26));
        c.drawCircle(443f, 35f, 23f, stroke);
        paint.setColor(Color.rgb(24, 33, 26));
        c.drawRect(435f, 26f, 440f, 44f, paint);
        c.drawRect(446f, 26f, 451f, 44f, paint);
    }

    private void drawControls(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(196, 214, 173));
        c.drawRect(0f, PLAY_BOTTOM, VW, VH, paint);
        paint.setColor(leftPressed ? Color.rgb(70, 92, 73) : Color.rgb(91, 115, 92));
        RectF left = new RectF(35f, 682f, 210f, 775f);
        c.drawRoundRect(left, 24f, 24f, paint);
        paint.setColor(rightPressed ? Color.rgb(70, 92, 73) : Color.rgb(91, 115, 92));
        RectF right = new RectF(270f, 682f, 445f, 775f);
        c.drawRoundRect(right, 24f, 24f, paint);
        stroke.setStrokeWidth(3f);
        stroke.setColor(Color.rgb(24, 33, 26));
        c.drawRoundRect(left, 24f, 24f, stroke);
        c.drawRoundRect(right, 24f, 24f, stroke);

        paint.setColor(Color.rgb(218, 231, 196));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        paint.setTextSize(54f);
        c.drawText("◀", 122f, 748f, paint);
        c.drawText("▶", 357f, 748f, paint);
    }

    private void drawPauseOverlay(Canvas c) {
        paint.setColor(Color.argb(175, 24, 33, 26));
        c.drawRect(0f, 0f, VW, VH, paint);
        paint.setColor(Color.rgb(232, 240, 216));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        paint.setTextSize(42f);
        c.drawText("PAUSED", VW / 2f, 320f, paint);
        paint.setTextSize(18f);
        c.drawText("Tap anywhere to continue", VW / 2f, 365f, paint);
        c.drawText("Tap top-left corner to restart level", VW / 2f, 398f, paint);
    }

    private void drawLevelComplete(Canvas c) {
        paint.setColor(Color.argb(190, 24, 33, 26));
        c.drawRect(0f, 0f, VW, VH, paint);
        paint.setColor(Color.rgb(232, 240, 216));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        paint.setTextSize(38f);
        c.drawText(level == 3 ? "ALL LEVELS CLEAR!" : "LEVEL CLEAR!", VW / 2f, 300f, paint);
        paint.setTextSize(19f);
        if (level < 3) c.drawText("Tap to play Level " + (level + 1), VW / 2f, 355f, paint);
        else c.drawText("Tap to return to menu", VW / 2f, 355f, paint);
    }

    private void drawGameOver(Canvas c) {
        paint.setColor(Color.argb(190, 24, 33, 26));
        c.drawRect(0f, 0f, VW, VH, paint);
        paint.setColor(Color.rgb(232, 240, 216));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        paint.setTextSize(42f);
        c.drawText("GAME OVER", VW / 2f, 305f, paint);
        paint.setTextSize(19f);
        c.drawText("Tap to retry Level " + level, VW / 2f, 360f, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float scaleX = VW / getWidth();
        float scaleY = VH / getHeight();
        int action = e.getActionMasked();
        int index = e.getActionIndex();
        float x = e.getX(index) * scaleX;
        float y = e.getY(index) * scaleY;
        int id = e.getPointerId(index);

        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            if (state == MENU) {
                if (unlockedLevel > 1 && y >= 460f && y <= 550f && x < 90f) {
                    level--;
                    if (level < 1) level = unlockedLevel;
                    invalidate();
                    return true;
                }
                if (unlockedLevel > 1 && y >= 460f && y <= 550f && x > 390f) {
                    level++;
                    if (level > unlockedLevel) level = 1;
                    invalidate();
                    return true;
                }
                if (y >= 440f && y <= 575f) {
                    startLevel(level, true);
                    return true;
                }
                return true;
            }

            if (state == LEVEL_COMPLETE) {
                if (SystemClock.elapsedRealtime() - stateSince < 250) return true;
                if (level < 3) startLevel(level + 1, true);
                else {
                    state = MENU;
                    level = unlockedLevel;
                }
                return true;
            }

            if (state == GAME_OVER) {
                if (SystemClock.elapsedRealtime() - stateSince < 250) return true;
                startLevel(level, true);
                return true;
            }

            if (paused) {
                if (x < 95f && y < 95f) startLevel(level, false);
                else paused = false;
                return true;
            }

            if (x > 408f && y < 74f) {
                paused = true;
                leftPressed = rightPressed = false;
                leftPointer = rightPointer = -1;
                return true;
            }

            if (y >= PLAY_BOTTOM) {
                if (x < VW / 2f) {
                    leftPressed = true;
                    leftPointer = id;
                } else {
                    rightPressed = true;
                    rightPointer = id;
                }
                return true;
            }
        }

        if (action == MotionEvent.ACTION_MOVE && state == PLAYING && !paused) {
            boolean leftNow = false, rightNow = false;
            int newLeftId = -1, newRightId = -1;
            for (int i = 0; i < e.getPointerCount(); i++) {
                float px = e.getX(i) * scaleX;
                float py = e.getY(i) * scaleY;
                int pid = e.getPointerId(i);
                if (py >= PLAY_BOTTOM) {
                    if (px < VW / 2f) { leftNow = true; newLeftId = pid; }
                    else { rightNow = true; newRightId = pid; }
                }
            }
            leftPressed = leftNow;
            rightPressed = rightNow;
            leftPointer = newLeftId;
            rightPointer = newRightId;
            return true;
        }

        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) {
            if (id == leftPointer) { leftPressed = false; leftPointer = -1; }
            if (id == rightPointer) { rightPressed = false; rightPointer = -1; }
            return true;
        }

        if (action == MotionEvent.ACTION_CANCEL) {
            leftPressed = rightPressed = false;
            leftPointer = rightPointer = -1;
            return true;
        }
        return true;
    }

    private static class Platform {
        final float x, y, w, h;
        Platform(float x, float y, float w, float h) { this.x = x; this.y = y; this.w = w; this.h = h; }
    }

    private static class Spike {
        final float x, y, w, h;
        Spike(float x, float y, float w, float h) { this.x = x; this.y = y; this.w = w; this.h = h; }
    }

    private static class Ring {
        final float x, y;
        boolean collected = false;
        Ring(float x, float y) { this.x = x; this.y = y; }
    }

    private static class SpringPad {
        final float x, y, w, h;
        SpringPad(float x, float y, float w, float h) { this.x = x; this.y = y; this.w = w; this.h = h; }
    }

    private static class Checkpoint {
        final float x, y;
        boolean activated = false;
        Checkpoint(float x, float y) { this.x = x; this.y = y; }
    }
}
